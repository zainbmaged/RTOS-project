#ifndef DELAY_H
#define DELAY_H

void Delay_Ms(int n);
void delay_Us(int n);

#endif //DELAY_H